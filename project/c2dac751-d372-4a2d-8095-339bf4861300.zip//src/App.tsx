import React, { useState } from "react";
import {
  ArrowRight,
  Brain,
  Zap,
  Users,
  BookOpen,
  Network,
  MessageSquare,
  PieChart,
  Award,
  Database,
  LineChart,
} from "lucide-react";

const VacSimPipeline = () => {
  const [hoveredNode, setHoveredNode] = useState(null);

  return (
    <div className="bg-gradient-to-br from-slate-50 to-blue-50 p-6 rounded-xl">
      <div className="text-center mb-6">
        <h1 className="text-2xl font-bold text-blue-800">
          VACSIM: LLM-Powered Vaccine Hesitancy Simulation
        </h1>
        <p className="text-gray-600 mt-1">
          An agent-based cognitive framework for public health intervention
          modeling
        </p>
      </div>

      {/* Pipeline Workflow Diagram */}
      <div className="relative overflow-x-auto mb-8">
        <svg className="mx-auto" width="900" height="400" viewBox="0 0 900 400">
          {/* Background Grid */}
          <defs>
            <pattern
              id="grid"
              width="20"
              height="20"
              patternUnits="userSpaceOnUse"
            >
              <path
                d="M 20 0 L 0 0 0 20"
                fill="none"
                stroke="rgba(0,0,0,0.03)"
                strokeWidth="1"
              />
            </pattern>
          </defs>
          <rect width="900" height="400" fill="url(#grid)" />

          {/* Connecting Lines */}
          <path
            d="M 120 200 L 220 200"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 320 200 L 420 200"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 520 200 L 620 200"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 720 200 L 820 200"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />

          <path
            d="M 170 130 L 270 130"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 370 130 L 470 130"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 570 130 L 670 130"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />

          <path
            d="M 170 270 L 270 270"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 370 270 L 470 270"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 570 270 L 670 270"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />

          {/* Vertical connections */}
          <path
            d="M 70 60 L 70 340"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 170 60 L 170 340"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 270 60 L 270 340"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 370 60 L 370 340"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 470 60 L 470 340"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 570 60 L 570 340"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 670 60 L 670 340"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 770 60 L 770 340"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />
          <path
            d="M 870 60 L 870 340"
            stroke="#94a3b8"
            strokeWidth="2"
            strokeDasharray="5,5"
          />

          {/* System Architecture - Top Row Label */}
          <text
            x="450"
            y="35"
            textAnchor="middle"
            fill="#1e40af"
            fontWeight="bold"
            fontSize="14"
          >
            System Architecture
          </text>

          {/* Flow Labels */}
          <text x="70" y="380" textAnchor="middle" fill="#475569" fontSize="12">
            Initialize
          </text>
          <text
            x="270"
            y="380"
            textAnchor="middle"
            fill="#475569"
            fontSize="12"
          >
            Process
          </text>
          <text
            x="470"
            y="380"
            textAnchor="middle"
            fill="#475569"
            fontSize="12"
          >
            Analyze
          </text>
          <text
            x="670"
            y="380"
            textAnchor="middle"
            fill="#475569"
            fontSize="12"
          >
            Generate
          </text>
          <text
            x="870"
            y="380"
            textAnchor="middle"
            fill="#475569"
            fontSize="12"
          >
            Evaluate
          </text>

          {/* Main Pipeline Flow - Center Row */}

          {/* LLM Foundation */}
          <g
            onMouseEnter={() => setHoveredNode("llm")}
            onMouseLeave={() => setHoveredNode(null)}
            style={{ cursor: "pointer" }}
          >
            <circle
              cx="70"
              cy="200"
              r="40"
              fill="url(#grad1)"
              stroke="#4338ca"
              strokeWidth="2"
            />
            <foreignObject x="40" y="170" width="60" height="60">
              <div className="flex items-center justify-center h-full w-full">
                <Brain size={32} color="#4338ca" />
              </div>
            </foreignObject>
            <text
              x="70"
              y="260"
              textAnchor="middle"
              fill="#1e3a8a"
              fontSize="12"
              fontWeight="bold"
            >
              LLM Foundation
            </text>

            {hoveredNode === "llm" && (
              <foreignObject x="20" y="85" width="200" height="100">
                <div className="bg-white p-2 rounded-lg shadow-lg text-xs border border-indigo-200">
                  <p className="font-bold text-indigo-700">
                    LLM-Powered Cognition
                  </p>
                  <p className="mt-1">
                    Large language models drive agent reasoning and learning
                    processes via OpenRouter API
                  </p>
                </div>
              </foreignObject>
            )}
          </g>

          {/* Agent Population */}
          <g
            onMouseEnter={() => setHoveredNode("agents")}
            onMouseLeave={() => setHoveredNode(null)}
            style={{ cursor: "pointer" }}
          >
            <circle
              cx="270"
              cy="200"
              r="40"
              fill="url(#grad2)"
              stroke="#0369a1"
              strokeWidth="2"
            />
            <foreignObject x="240" y="170" width="60" height="60">
              <div className="flex items-center justify-center h-full w-full">
                <Users size={32} color="#0369a1" />
              </div>
            </foreignObject>
            <text
              x="270"
              y="260"
              textAnchor="middle"
              fill="#1e3a8a"
              fontSize="12"
              fontWeight="bold"
            >
              Agent Population
            </text>

            {hoveredNode === "agents" && (
              <foreignObject x="170" y="85" width="200" height="100">
                <div className="bg-white p-2 rounded-lg shadow-lg text-xs border border-blue-200">
                  <p className="font-bold text-blue-700">
                    Diverse Virtual Agents
                  </p>
                  <p className="mt-1">
                    Demographically diverse population with memory systems and
                    evolving beliefs
                  </p>
                </div>
              </foreignObject>
            )}
          </g>

          {/* Information Processing */}
          <g
            onMouseEnter={() => setHoveredNode("info")}
            onMouseLeave={() => setHoveredNode(null)}
            style={{ cursor: "pointer" }}
          >
            <circle
              cx="470"
              cy="200"
              r="40"
              fill="url(#grad3)"
              stroke="#0d9488"
              strokeWidth="2"
            />
            <foreignObject x="440" y="170" width="60" height="60">
              <div className="flex items-center justify-center h-full w-full">
                <BookOpen size={32} color="#0d9488" />
              </div>
            </foreignObject>
            <text
              x="470"
              y="260"
              textAnchor="middle"
              fill="#1e3a8a"
              fontSize="12"
              fontWeight="bold"
            >
              Information Processing
            </text>

            {hoveredNode === "info" && (
              <foreignObject x="370" y="85" width="200" height="100">
                <div className="bg-white p-2 rounded-lg shadow-lg text-xs border border-teal-200">
                  <p className="font-bold text-teal-700">
                    Information Integration
                  </p>
                  <p className="mt-1">
                    Agents process news, policies, and social content through
                    cognitive filters
                  </p>
                </div>
              </foreignObject>
            )}
          </g>

          {/* Attitude Formation */}
          <g
            onMouseEnter={() => setHoveredNode("attitude")}
            onMouseLeave={() => setHoveredNode(null)}
            style={{ cursor: "pointer" }}
          >
            <circle
              cx="670"
              cy="200"
              r="40"
              fill="url(#grad4)"
              stroke="#ca8a04"
              strokeWidth="2"
            />
            <foreignObject x="640" y="170" width="60" height="60">
              <div className="flex items-center justify-center h-full w-full">
                <PieChart size={32} color="#ca8a04" />
              </div>
            </foreignObject>
            <text
              x="670"
              y="260"
              textAnchor="middle"
              fill="#1e3a8a"
              fontSize="12"
              fontWeight="bold"
            >
              Attitude Formation
            </text>

            {hoveredNode === "attitude" && (
              <foreignObject x="570" y="85" width="200" height="100">
                <div className="bg-white p-2 rounded-lg shadow-lg text-xs border border-yellow-200">
                  <p className="font-bold text-yellow-700">
                    Probabilistic Decision Making
                  </p>
                  <p className="mt-1">
                    Temperature-modulated attitude distributions create
                    realistic hesitancy profiles
                  </p>
                </div>
              </foreignObject>
            )}
          </g>

          {/* Impact Analysis */}
          <g
            onMouseEnter={() => setHoveredNode("impact")}
            onMouseLeave={() => setHoveredNode(null)}
            style={{ cursor: "pointer" }}
          >
            <circle
              cx="870"
              cy="200"
              r="40"
              fill="url(#grad5)"
              stroke="#be123c"
              strokeWidth="2"
            />
            <foreignObject x="840" y="170" width="60" height="60">
              <div className="flex items-center justify-center h-full w-full">
                <LineChart size={32} color="#be123c" />
              </div>
            </foreignObject>
            <text
              x="870"
              y="260"
              textAnchor="middle"
              fill="#1e3a8a"
              fontSize="12"
              fontWeight="bold"
            >
              Impact Analysis
            </text>

            {hoveredNode === "impact" && (
              <foreignObject x="770" y="85" width="200" height="100">
                <div className="bg-white p-2 rounded-lg shadow-lg text-xs border border-rose-200">
                  <p className="font-bold text-rose-700">
                    Policy Effectiveness
                  </p>
                  <p className="mt-1">
                    Longitudinal tracking of hesitancy rates in response to
                    policy interventions
                  </p>
                </div>
              </foreignObject>
            )}
          </g>

          {/* Upper Row - Data Inputs */}

          {/* Demographic Data */}
          <g
            onMouseEnter={() => setHoveredNode("demographics")}
            onMouseLeave={() => setHoveredNode(null)}
            style={{ cursor: "pointer" }}
          >
            <circle
              cx="170"
              cy="130"
              r="30"
              fill="url(#grad6)"
              stroke="#6366f1"
              strokeWidth="2"
            />
            <foreignObject x="145" y="105" width="50" height="50">
              <div className="flex items-center justify-center h-full w-full">
                <Database size={24} color="#6366f1" />
              </div>
            </foreignObject>
            <text
              x="170"
              y="175"
              textAnchor="middle"
              fill="#1e3a8a"
              fontSize="11"
              fontWeight="bold"
            >
              Demographics
            </text>

            {hoveredNode === "demographics" && (
              <foreignObject x="120" y="45" width="180" height="70">
                <div className="bg-white p-2 rounded-lg shadow-lg text-xs border border-indigo-200">
                  <p className="font-bold text-indigo-600">Agent Profiles</p>
                  <p className="mt-1">
                    Age, education, political beliefs, religion
                  </p>
                </div>
              </foreignObject>
            )}
          </g>

          {/* News & Policy */}
          <g
            onMouseEnter={() => setHoveredNode("news")}
            onMouseLeave={() => setHoveredNode(null)}
            style={{ cursor: "pointer" }}
          >
            <circle
              cx="370"
              cy="130"
              r="30"
              fill="url(#grad7)"
              stroke="#0891b2"
              strokeWidth="2"
            />
            <foreignObject x="345" y="105" width="50" height="50">
              <div className="flex items-center justify-center h-full w-full">
                <BookOpen size={24} color="#0891b2" />
              </div>
            </foreignObject>
            <text
              x="370"
              y="175"
              textAnchor="middle"
              fill="#1e3a8a"
              fontSize="11"
              fontWeight="bold"
            >
              News & Policy
            </text>

            {hoveredNode === "news" && (
              <foreignObject x="320" y="45" width="180" height="70">
                <div className="bg-white p-2 rounded-lg shadow-lg text-xs border border-cyan-200">
                  <p className="font-bold text-cyan-600">Information Sources</p>
                  <p className="mt-1">
                    Pro/anti vaccine news, policy interventions
                  </p>
                </div>
              </foreignObject>
            )}
          </g>

          {/* Disease Risk */}
          <g
            onMouseEnter={() => setHoveredNode("risk")}
            onMouseLeave={() => setHoveredNode(null)}
            style={{ cursor: "pointer" }}
          >
            <circle
              cx="570"
              cy="130"
              r="30"
              fill="url(#grad8)"
              stroke="#059669"
              strokeWidth="2"
            />
            <foreignObject x="545" y="105" width="50" height="50">
              <div className="flex items-center justify-center h-full w-full">
                <Zap size={24} color="#059669" />
              </div>
            </foreignObject>
            <text
              x="570"
              y="175"
              textAnchor="middle"
              fill="#1e3a8a"
              fontSize="11"
              fontWeight="bold"
            >
              Disease Risk
            </text>

            {hoveredNode === "risk" && (
              <foreignObject x="520" y="45" width="180" height="70">
                <div className="bg-white p-2 rounded-lg shadow-lg text-xs border border-emerald-200">
                  <p className="font-bold text-emerald-600">Risk Dynamics</p>
                  <p className="mt-1">
                    Changing disease prevalence and severity
                  </p>
                </div>
              </foreignObject>
            )}
          </g>

          {/* Lower Row - Outputs */}

          {/* Memory & Lessons */}
          <g
            onMouseEnter={() => setHoveredNode("memory")}
            onMouseLeave={() => setHoveredNode(null)}
            style={{ cursor: "pointer" }}
          >
            <circle
              cx="170"
              cy="270"
              r="30"
              fill="url(#grad9)"
              stroke="#7c3aed"
              strokeWidth="2"
            />
            <foreignObject x="145" y="245" width="50" height="50">
              <div className="flex items-center justify-center h-full w-full">
                <Brain size={24} color="#7c3aed" />
              </div>
            </foreignObject>
            <text
              x="170"
              y="315"
              textAnchor="middle"
              fill="#1e3a8a"
              fontSize="11"
              fontWeight="bold"
            >
              Memory System
            </text>

            {hoveredNode === "memory" && (
              <foreignObject x="120" y="285" width="180" height="70">
                <div className="bg-white p-2 rounded-lg shadow-lg text-xs border border-violet-200">
                  <p className="font-bold text-violet-600">Cognitive Memory</p>
                  <p className="mt-1">
                    Time-decaying personal lessons with importance weighting
                  </p>
                </div>
              </foreignObject>
            )}
          </g>

          {/* Social Network */}
          <g
            onMouseEnter={() => setHoveredNode("social")}
            onMouseLeave={() => setHoveredNode(null)}
            style={{ cursor: "pointer" }}
          >
            <circle
              cx="370"
              cy="270"
              r="30"
              fill="url(#grad10)"
              stroke="#2563eb"
              strokeWidth="2"
            />
            <foreignObject x="345" y="245" width="50" height="50">
              <div className="flex items-center justify-center h-full w-full">
                <Network size={24} color="#2563eb" />
              </div>
            </foreignObject>
            <text
              x="370"
              y="315"
              textAnchor="middle"
              fill="#1e3a8a"
              fontSize="11"
              fontWeight="bold"
            >
              Social Network
            </text>

            {hoveredNode === "social" && (
              <foreignObject x="320" y="285" width="180" height="70">
                <div className="bg-white p-2 rounded-lg shadow-lg text-xs border border-blue-200">
                  <p className="font-bold text-blue-600">Network Dynamics</p>
                  <p className="mt-1">
                    Information flow through agent connection graph
                  </p>
                </div>
              </foreignObject>
            )}
          </g>

          {/* Tweet Generation */}
          <g
            onMouseEnter={() => setHoveredNode("tweets")}
            onMouseLeave={() => setHoveredNode(null)}
            style={{ cursor: "pointer" }}
          >
            <circle
              cx="570"
              cy="270"
              r="30"
              fill="url(#grad11)"
              stroke="#ea580c"
              strokeWidth="2"
            />
            <foreignObject x="545" y="245" width="50" height="50">
              <div className="flex items-center justify-center h-full w-full">
                <MessageSquare size={24} color="#ea580c" />
              </div>
            </foreignObject>
            <text
              x="570"
              y="315"
              textAnchor="middle"
              fill="#1e3a8a"
              fontSize="11"
              fontWeight="bold"
            >
              Social Messages
            </text>

            {hoveredNode === "tweets" && (
              <foreignObject x="520" y="285" width="180" height="70">
                <div className="bg-white p-2 rounded-lg shadow-lg text-xs border border-orange-200">
                  <p className="font-bold text-orange-600">Tweet Generation</p>
                  <p className="mt-1">
                    Personalized content creation reflecting agent attitudes
                  </p>
                </div>
              </foreignObject>
            )}
          </g>

          {/* Gradients for nodes */}
          <defs>
            <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#c7d2fe" />
              <stop offset="100%" stopColor="#a5b4fc" />
            </linearGradient>
            <linearGradient id="grad2" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#bfdbfe" />
              <stop offset="100%" stopColor="#93c5fd" />
            </linearGradient>
            <linearGradient id="grad3" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#99f6e4" />
              <stop offset="100%" stopColor="#5eead4" />
            </linearGradient>
            <linearGradient id="grad4" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fef9c3" />
              <stop offset="100%" stopColor="#fde047" />
            </linearGradient>
            <linearGradient id="grad5" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fecdd3" />
              <stop offset="100%" stopColor="#fda4af" />
            </linearGradient>
            <linearGradient id="grad6" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#e0e7ff" />
              <stop offset="100%" stopColor="#c7d2fe" />
            </linearGradient>
            <linearGradient id="grad7" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#cffafe" />
              <stop offset="100%" stopColor="#a5f3fc" />
            </linearGradient>
            <linearGradient id="grad8" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#d1fae5" />
              <stop offset="100%" stopColor="#a7f3d0" />
            </linearGradient>
            <linearGradient id="grad9" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ede9fe" />
              <stop offset="100%" stopColor="#ddd6fe" />
            </linearGradient>
            <linearGradient id="grad10" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#dbeafe" />
              <stop offset="100%" stopColor="#bfdbfe" />
            </linearGradient>
            <linearGradient id="grad11" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#ffedd5" />
              <stop offset="100%" stopColor="#fed7aa" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Key Innovation Callouts */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-3 rounded-lg border border-indigo-100">
          <div className="flex items-center mb-2">
            <Brain size={20} className="text-indigo-600 mr-2" />
            <h3 className="font-bold text-indigo-800">LLM-Powered Cognition</h3>
          </div>
          <p className="text-sm text-gray-700">
            Leverages large language models to create realistic agent reasoning,
            memory formation, and belief systems
          </p>
        </div>

        <div className="bg-gradient-to-br from-cyan-50 to-blue-50 p-3 rounded-lg border border-blue-100">
          <div className="flex items-center mb-2">
            <Zap size={20} className="text-blue-600 mr-2" />
            <h3 className="font-bold text-blue-800">Time-Decaying Memory</h3>
          </div>
          <p className="text-sm text-gray-700">
            Cognitive memory system with importance-weighted lessons and
            temporal decay for realistic belief evolution
          </p>
        </div>

        <div className="bg-gradient-to-br from-amber-50 to-yellow-50 p-3 rounded-lg border border-amber-100">
          <div className="flex items-center mb-2">
            <PieChart size={20} className="text-amber-600 mr-2" />
            <h3 className="font-bold text-amber-800">
              Probabilistic Attitudes
            </h3>
          </div>
          <p className="text-sm text-gray-700">
            Temperature-modulated attitude distributions create realistic
            variance in agent decision making
          </p>
        </div>
      </div>

      {/* Technical Summary */}
      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
        <h3 className="font-bold text-gray-700 mb-2">
          Technical Architecture Highlights
        </h3>
        <ul className="list-disc list-inside text-sm text-gray-600 grid grid-cols-1 md:grid-cols-2 gap-2">
          <li>OpenRouter API integration for multi-model LLM access</li>
          <li>Agent population with demographic diversity</li>
          <li>Robust lesson parsing with importance scoring</li>
          <li>Advanced text generation for tweet simulation</li>
          <li>Social network data structures for information flow</li>
          <li>Memory saliency calculation for relevant recall</li>
          <li>Temperature-controlled response distributions</li>
          <li>Longitudinal data capture for trend analysis</li>
        </ul>
      </div>

      {/* Hackathon-Ready Footer */}
      <div className="mt-5 text-center">
        <div className="inline-flex items-center bg-blue-600 px-3 py-1 rounded-full">
          <Award className="text-white mr-2" size={16} />
          <span className="text-white text-sm font-medium">
            VACSIM: Modeling the Future of Public Health Communication
          </span>
        </div>
      </div>
    </div>
  );
};

export default VacSimPipeline;
